(() => {
  let __hasOwnProperty = Object.hasOwnProperty;
  let __modules = {};
  let __commonjs;
  let __require = (id) => {
    let module = __modules[id];
    if (!module) {
      module = __modules[id] = {
        exports: {}
      };
      __commonjs[id](module.exports, module);
    }
    return module.exports;
  };
  let __toModule = (module) => {
    if (module && module.__esModule) {
      return module;
    }
    let result = {};
    for (let key in module) {
      if (__hasOwnProperty.call(module, key)) {
        result[key] = module[key];
      }
    }
    result.default = module;
    return result;
  };
  let __import = (id) => {
    return __toModule(__require(id));
  };
  __commonjs = {
    0(exports, module) {
      // node_modules/handlebars-helper-ternary/index.js
      "use strict";
      module.exports = function(test, yes, no) {
        return (typeof test === "function" ? test.call(this) : test) ? yes : no;
      };
    },

    8() {
      // src/module/settings.ts
      const handlebars_helper_ternary = __import(0 /* handlebars-helper-ternary */);
      var helpers = require("handlebars-helpers")(["object"]);
      console.log(helpers);
      const MODULE_NAME = "progressclocks";
      var CLOCKS_SETTINGS_KEYS;
      (function(CLOCKS_SETTINGS_KEYS2) {
        CLOCKS_SETTINGS_KEYS2["clocks"] = `clocks_v1`;
        CLOCKS_SETTINGS_KEYS2["localSettings"] = "localsettings_v1";
      })(CLOCKS_SETTINGS_KEYS || (CLOCKS_SETTINGS_KEYS = {}));
      var CLOCKS_HOOKS;
      (function(CLOCKS_HOOKS2) {
        CLOCKS_HOOKS2["clockSettingsUpdate"] = "clockSettingsUpdate";
      })(CLOCKS_HOOKS || (CLOCKS_HOOKS = {}));
      const registerSettings = function() {
        console.log(`${MODULE_NAME} | Registering settings`);
        game.settings.register(MODULE_NAME, CLOCKS_SETTINGS_KEYS.clocks, {
          name: "Clocks",
          scope: "world",
          config: false,
          default: [],
          type: Object,
          onChange: (newClocks) => Hooks.call(CLOCKS_HOOKS.clockSettingsUpdate)
        });
        Handlebars.registerHelper("get", helpers.get);
        Handlebars.registerHelper("ternary", handlebars_helper_ternary.default);
      };

      // src/module/preloadTemplates.ts
      const preloadTemplates2 = async function() {
        const templatePaths = [];
        return loadTemplates(templatePaths);
      };

      // src/module/Clock.ts
      const lodash = __import(1 /* lodash.update */);
      const clockTemplate = `modules/${MODULE_NAME}/templates/clock.html`;
      class Clock2 extends Application {
        constructor(options) {
          super({
            ...options,
            template: clockTemplate
          });
          this.getTicks = () => this.options.ticks;
          this.getId = () => this._id;
          this._setClock = (options) => {
            this.options = {
              ...this.options,
              ...options
            };
            if (this.options.segments < 2)
              this.options.segments = 2;
            if (this.options.segments < this.options.ticks)
              this.options.ticks = this.options.segments;
            Clock2.setClock(this._id, this.options);
            this.render(true, this.options);
          };
          options.template = clockTemplate;
          if (options.segments <= 1) {
            throw new Error("Clocks need at least 2 segments");
          }
          this.options.segments = options.segments;
          this.options.ticks = options.ticks;
          this._id = options._id || new Date().valueOf();
          if (Clock2.userHasEditPermissions) {
            this._setClock(this.options);
          }
        }
        static get defaultOptions() {
          const obj = mergeObject(super.defaultOptions, {
            segments: 4,
            ticks: 0,
            popOut: false,
            resizable: false,
            width: 64,
            template: clockTemplate,
            classes: ["progress-clocks", "clock"]
          });
          return obj;
        }
        static get userHasEditPermissions() {
          return game.user.hasRole(game?.permissions?.SETTINGS_MODIFY[0] ?? CONST.USER_ROLES.ASSISTANT);
        }
      }
      Clock2.resetClocks = () => {
        return game.settings.set(MODULE_NAME, CLOCKS_SETTINGS_KEYS.clocks, []);
      };
      Clock2.getClocks = () => {
        return game.settings.get(MODULE_NAME, CLOCKS_SETTINGS_KEYS.clocks);
      };
      Clock2.createClock = (newClock = {
        ticks: 1,
        segments: 4,
        _id: new Date().valueOf(),
        title: "New Clock"
      }) => {
        const clocks3 = Clock2.getClocks();
        game.settings.set(MODULE_NAME, CLOCKS_SETTINGS_KEYS.clocks, [...clocks3, newClock]);
      };
      Clock2.setClock = (id, options) => {
        if (!Clock2.userHasEditPermissions) {
          console.warn("User lacks edit permissions");
          return;
        }
        const clocks3 = Clock2.getClocks();
        const idx = clocks3.findIndex(({_id}) => id === _id);
        if (idx < 0) {
          console.error(`No clock found with id ${id}`);
          return;
        }
        const newClocks = lodash.default(clocks3, `[${idx}]`, (clock) => ({
          ...clock,
          ...options,
          segments: Math.max(2, options.segments || clock.segments)
        }));
        game.settings.set(MODULE_NAME, CLOCKS_SETTINGS_KEYS.clocks, newClocks);
      };

      // src/module/util/clocks.ts
      const getSegmentPaths = ({segments, size}) => {
        const segmentSizes = 360 / segments;
        const radius = size / 2;
        const pathTransforms = Array(segments).fill(void 0).map((_2, idx) => {
          const position = idx * segmentSizes - (segments % 2 !== 0 ? 0.5 * segmentSizes : 0);
          const rad = position * (Math.PI / 180);
          const arr = [Math.cos(rad) * radius + size / 2, Math.sin(rad) * radius + size / 2];
          return arr;
        });
        return pathTransforms;
      };
      const generateClockTemplatePayload = ({id, segments, size, ticks, title, edit}) => {
        const pathTransforms = getSegmentPaths({
          segments,
          size
        });
        const data = {
          segments,
          ticks,
          percent: ticks / segments * 100,
          pathTransforms,
          size,
          id,
          title,
          edit
        };
        return data;
      };

      // node_modules/roughjs/bundled/rough.esm.js
      function t(t2, e2, s2) {
        if (t2 && t2.length) {
          const [n2, o2] = e2, a2 = Math.PI / 180 * s2, h2 = Math.cos(a2), r2 = Math.sin(a2);
          t2.forEach((t3) => {
            const [e3, s3] = t3;
            t3[0] = (e3 - n2) * h2 - (s3 - o2) * r2 + n2, t3[1] = (e3 - n2) * r2 + (s3 - o2) * h2 + o2;
          });
        }
      }
      function e(t2) {
        const e2 = t2[0], s2 = t2[1];
        return Math.sqrt(Math.pow(e2[0] - s2[0], 2) + Math.pow(e2[1] - s2[1], 2));
      }
      function s(t2, e2, s2, n2) {
        const o2 = e2[1] - t2[1], a2 = t2[0] - e2[0], h2 = o2 * t2[0] + a2 * t2[1], r2 = n2[1] - s2[1], i2 = s2[0] - n2[0], c2 = r2 * s2[0] + i2 * s2[1], l2 = o2 * i2 - r2 * a2;
        return l2 ? [(i2 * h2 - a2 * c2) / l2, (o2 * c2 - r2 * h2) / l2] : null;
      }
      function n(t2, e2, s2) {
        const n2 = t2.length;
        if (n2 < 3)
          return false;
        const r2 = [Number.MAX_SAFE_INTEGER, s2], i2 = [e2, s2];
        let c2 = 0;
        for (let e3 = 0; e3 < n2; e3++) {
          const s3 = t2[e3], l2 = t2[(e3 + 1) % n2];
          if (h(s3, l2, i2, r2)) {
            if (0 === a(s3, i2, l2))
              return o(s3, i2, l2);
            c2++;
          }
        }
        return c2 % 2 == 1;
      }
      function o(t2, e2, s2) {
        return e2[0] <= Math.max(t2[0], s2[0]) && e2[0] >= Math.min(t2[0], s2[0]) && e2[1] <= Math.max(t2[1], s2[1]) && e2[1] >= Math.min(t2[1], s2[1]);
      }
      function a(t2, e2, s2) {
        const n2 = (e2[1] - t2[1]) * (s2[0] - e2[0]) - (e2[0] - t2[0]) * (s2[1] - e2[1]);
        return 0 === n2 ? 0 : n2 > 0 ? 1 : 2;
      }
      function h(t2, e2, s2, n2) {
        const h2 = a(t2, e2, s2), r2 = a(t2, e2, n2), i2 = a(s2, n2, t2), c2 = a(s2, n2, e2);
        return h2 !== r2 && i2 !== c2 || (!(0 !== h2 || !o(t2, s2, e2)) || (!(0 !== r2 || !o(t2, n2, e2)) || (!(0 !== i2 || !o(s2, t2, n2)) || !(0 !== c2 || !o(s2, e2, n2)))));
      }
      function r(e2, s2) {
        const n2 = [0, 0], o2 = Math.round(s2.hachureAngle + 90);
        o2 && t(e2, n2, o2);
        const a2 = function(t2, e3) {
          const s3 = [...t2];
          s3[0].join(",") !== s3[s3.length - 1].join(",") && s3.push([s3[0][0], s3[0][1]]);
          const n3 = [];
          if (s3 && s3.length > 2) {
            let t3 = e3.hachureGap;
            t3 < 0 && (t3 = 4 * e3.strokeWidth), t3 = Math.max(t3, 0.1);
            const o3 = [];
            for (let t4 = 0; t4 < s3.length - 1; t4++) {
              const e4 = s3[t4], n4 = s3[t4 + 1];
              if (e4[1] !== n4[1]) {
                const t5 = Math.min(e4[1], n4[1]);
                o3.push({
                  ymin: t5,
                  ymax: Math.max(e4[1], n4[1]),
                  x: t5 === e4[1] ? e4[0] : n4[0],
                  islope: (n4[0] - e4[0]) / (n4[1] - e4[1])
                });
              }
            }
            if (o3.sort((t4, e4) => t4.ymin < e4.ymin ? -1 : t4.ymin > e4.ymin ? 1 : t4.x < e4.x ? -1 : t4.x > e4.x ? 1 : t4.ymax === e4.ymax ? 0 : (t4.ymax - e4.ymax) / Math.abs(t4.ymax - e4.ymax)), !o3.length)
              return n3;
            let a3 = [], h2 = o3[0].ymin;
            for (; a3.length || o3.length; ) {
              if (o3.length) {
                let t4 = -1;
                for (let e4 = 0; e4 < o3.length && !(o3[e4].ymin > h2); e4++)
                  t4 = e4;
                o3.splice(0, t4 + 1).forEach((t5) => {
                  a3.push({
                    s: h2,
                    edge: t5
                  });
                });
              }
              if (a3 = a3.filter((t4) => !(t4.edge.ymax <= h2)), a3.sort((t4, e4) => t4.edge.x === e4.edge.x ? 0 : (t4.edge.x - e4.edge.x) / Math.abs(t4.edge.x - e4.edge.x)), a3.length > 1)
                for (let t4 = 0; t4 < a3.length; t4 += 2) {
                  const e4 = t4 + 1;
                  if (e4 >= a3.length)
                    break;
                  const s4 = a3[t4].edge, o4 = a3[e4].edge;
                  n3.push([[Math.round(s4.x), h2], [Math.round(o4.x), h2]]);
                }
              h2 += t3, a3.forEach((e4) => {
                e4.edge.x = e4.edge.x + t3 * e4.edge.islope;
              });
            }
          }
          return n3;
        }(e2, s2);
        return o2 && (t(e2, n2, -o2), function(e3, s3, n3) {
          const o3 = [];
          e3.forEach((t2) => o3.push(...t2)), t(o3, s3, n3);
        }(a2, n2, -o2)), a2;
      }
      class i {
        constructor(t2) {
          this.helper = t2;
        }
        fillPolygon(t2, e2) {
          return this._fillPolygon(t2, e2);
        }
        _fillPolygon(t2, e2, s2 = false) {
          let n2 = r(t2, e2);
          if (s2) {
            const e3 = this.connectingLines(t2, n2);
            n2 = n2.concat(e3);
          }
          return {
            type: "fillSketch",
            ops: this.renderLines(n2, e2)
          };
        }
        renderLines(t2, e2) {
          const s2 = [];
          for (const n2 of t2)
            s2.push(...this.helper.doubleLineOps(n2[0][0], n2[0][1], n2[1][0], n2[1][1], e2));
          return s2;
        }
        connectingLines(t2, s2) {
          const n2 = [];
          if (s2.length > 1)
            for (let o2 = 1; o2 < s2.length; o2++) {
              const a2 = s2[o2 - 1];
              if (e(a2) < 3)
                continue;
              const h2 = [s2[o2][0], a2[1]];
              if (e(h2) > 3) {
                const e2 = this.splitOnIntersections(t2, h2);
                n2.push(...e2);
              }
            }
          return n2;
        }
        midPointInPolygon(t2, e2) {
          return n(t2, (e2[0][0] + e2[1][0]) / 2, (e2[0][1] + e2[1][1]) / 2);
        }
        splitOnIntersections(t2, o2) {
          const a2 = Math.max(5, 0.1 * e(o2)), r2 = [];
          for (let n2 = 0; n2 < t2.length; n2++) {
            const i2 = t2[n2], c2 = t2[(n2 + 1) % t2.length];
            if (h(i2, c2, ...o2)) {
              const t3 = s(i2, c2, o2[0], o2[1]);
              if (t3) {
                const s2 = e([t3, o2[0]]), n3 = e([t3, o2[1]]);
                s2 > a2 && n3 > a2 && r2.push({
                  point: t3,
                  distance: s2
                });
              }
            }
          }
          if (r2.length > 1) {
            const e2 = r2.sort((t3, e3) => t3.distance - e3.distance).map((t3) => t3.point);
            if (n(t2, ...o2[0]) || e2.shift(), n(t2, ...o2[1]) || e2.pop(), e2.length <= 1)
              return this.midPointInPolygon(t2, o2) ? [o2] : [];
            const s2 = [o2[0], ...e2, o2[1]], a3 = [];
            for (let e3 = 0; e3 < s2.length - 1; e3 += 2) {
              const n2 = [s2[e3], s2[e3 + 1]];
              this.midPointInPolygon(t2, n2) && a3.push(n2);
            }
            return a3;
          }
          return this.midPointInPolygon(t2, o2) ? [o2] : [];
        }
      }
      class c extends i {
        fillPolygon(t2, e2) {
          return this._fillPolygon(t2, e2, true);
        }
      }
      class l extends i {
        fillPolygon(t2, e2) {
          const s2 = this._fillPolygon(t2, e2), n2 = Object.assign({}, e2, {
            hachureAngle: e2.hachureAngle + 90
          }), o2 = this._fillPolygon(t2, n2);
          return s2.ops = s2.ops.concat(o2.ops), s2;
        }
      }
      class u {
        constructor(t2) {
          this.helper = t2;
        }
        fillPolygon(t2, e2) {
          const s2 = r(t2, e2 = Object.assign({}, e2, {
            curveStepCount: 4,
            hachureAngle: 0,
            roughness: 1
          }));
          return this.dotsOnLines(s2, e2);
        }
        dotsOnLines(t2, s2) {
          const n2 = [];
          let o2 = s2.hachureGap;
          o2 < 0 && (o2 = 4 * s2.strokeWidth), o2 = Math.max(o2, 0.1);
          let a2 = s2.fillWeight;
          a2 < 0 && (a2 = s2.strokeWidth / 2);
          const h2 = o2 / 4;
          for (const r2 of t2) {
            const t3 = e(r2), i2 = t3 / o2, c2 = Math.ceil(i2) - 1, l2 = t3 - c2 * o2, u2 = (r2[0][0] + r2[1][0]) / 2 - o2 / 4, p2 = Math.min(r2[0][1], r2[1][1]);
            for (let t4 = 0; t4 < c2; t4++) {
              const e2 = p2 + l2 + t4 * o2, r3 = this.helper.randOffsetWithRange(u2 - h2, u2 + h2, s2), i3 = this.helper.randOffsetWithRange(e2 - h2, e2 + h2, s2), c3 = this.helper.ellipse(r3, i3, a2, a2, s2);
              n2.push(...c3.ops);
            }
          }
          return {
            type: "fillSketch",
            ops: n2
          };
        }
      }
      class p {
        constructor(t2) {
          this.helper = t2;
        }
        fillPolygon(t2, e2) {
          const s2 = r(t2, e2);
          return {
            type: "fillSketch",
            ops: this.dashedLine(s2, e2)
          };
        }
        dashedLine(t2, s2) {
          const n2 = s2.dashOffset < 0 ? s2.hachureGap < 0 ? 4 * s2.strokeWidth : s2.hachureGap : s2.dashOffset, o2 = s2.dashGap < 0 ? s2.hachureGap < 0 ? 4 * s2.strokeWidth : s2.hachureGap : s2.dashGap, a2 = [];
          return t2.forEach((t3) => {
            const h2 = e(t3), r2 = Math.floor(h2 / (n2 + o2)), i2 = (h2 + o2 - r2 * (n2 + o2)) / 2;
            let c2 = t3[0], l2 = t3[1];
            c2[0] > l2[0] && (c2 = t3[1], l2 = t3[0]);
            const u2 = Math.atan((l2[1] - c2[1]) / (l2[0] - c2[0]));
            for (let t4 = 0; t4 < r2; t4++) {
              const e2 = t4 * (n2 + o2), h3 = e2 + n2, r3 = [c2[0] + e2 * Math.cos(u2) + i2 * Math.cos(u2), c2[1] + e2 * Math.sin(u2) + i2 * Math.sin(u2)], l3 = [c2[0] + h3 * Math.cos(u2) + i2 * Math.cos(u2), c2[1] + h3 * Math.sin(u2) + i2 * Math.sin(u2)];
              a2.push(...this.helper.doubleLineOps(r3[0], r3[1], l3[0], l3[1], s2));
            }
          }), a2;
        }
      }
      class f {
        constructor(t2) {
          this.helper = t2;
        }
        fillPolygon(t2, e2) {
          const s2 = e2.hachureGap < 0 ? 4 * e2.strokeWidth : e2.hachureGap, n2 = e2.zigzagOffset < 0 ? s2 : e2.zigzagOffset, o2 = r(t2, e2 = Object.assign({}, e2, {
            hachureGap: s2 + n2
          }));
          return {
            type: "fillSketch",
            ops: this.zigzagLines(o2, n2, e2)
          };
        }
        zigzagLines(t2, s2, n2) {
          const o2 = [];
          return t2.forEach((t3) => {
            const a2 = e(t3), h2 = Math.round(a2 / (2 * s2));
            let r2 = t3[0], i2 = t3[1];
            r2[0] > i2[0] && (r2 = t3[1], i2 = t3[0]);
            const c2 = Math.atan((i2[1] - r2[1]) / (i2[0] - r2[0]));
            for (let t4 = 0; t4 < h2; t4++) {
              const e2 = 2 * t4 * s2, a3 = 2 * (t4 + 1) * s2, h3 = Math.sqrt(2 * Math.pow(s2, 2)), i3 = [r2[0] + e2 * Math.cos(c2), r2[1] + e2 * Math.sin(c2)], l2 = [r2[0] + a3 * Math.cos(c2), r2[1] + a3 * Math.sin(c2)], u2 = [i3[0] + h3 * Math.cos(c2 + Math.PI / 4), i3[1] + h3 * Math.sin(c2 + Math.PI / 4)];
              o2.push(...this.helper.doubleLineOps(i3[0], i3[1], u2[0], u2[1], n2), ...this.helper.doubleLineOps(u2[0], u2[1], l2[0], l2[1], n2));
            }
          }), o2;
        }
      }
      const d = {};
      class g {
        constructor(t2) {
          this.seed = t2;
        }
        next() {
          return this.seed ? (2 ** 31 - 1 & (this.seed = Math.imul(48271, this.seed))) / 2 ** 31 : Math.random();
        }
      }
      const M = {
        A: 7,
        a: 7,
        C: 6,
        c: 6,
        H: 1,
        h: 1,
        L: 2,
        l: 2,
        M: 2,
        m: 2,
        Q: 4,
        q: 4,
        S: 4,
        s: 4,
        T: 2,
        t: 2,
        V: 1,
        v: 1,
        Z: 0,
        z: 0
      };
      function k(t2, e2) {
        return t2.type === e2;
      }
      function y(t2) {
        const e2 = [], s2 = function(t3) {
          const e3 = new Array();
          for (; "" !== t3; )
            if (t3.match(/^([ \t\r\n,]+)/))
              t3 = t3.substr(RegExp.$1.length);
            else if (t3.match(/^([aAcChHlLmMqQsStTvVzZ])/))
              e3[e3.length] = {
                type: 0,
                text: RegExp.$1
              }, t3 = t3.substr(RegExp.$1.length);
            else {
              if (!t3.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/))
                return [];
              e3[e3.length] = {
                type: 1,
                text: "" + parseFloat(RegExp.$1)
              }, t3 = t3.substr(RegExp.$1.length);
            }
          return e3[e3.length] = {
            type: 2,
            text: ""
          }, e3;
        }(t2);
        let n2 = "BOD", o2 = 0, a2 = s2[o2];
        for (; !k(a2, 2); ) {
          let h2 = 0;
          const r2 = [];
          if ("BOD" === n2) {
            if ("M" !== a2.text && "m" !== a2.text)
              return y("M0,0" + t2);
            o2++, h2 = M[a2.text], n2 = a2.text;
          } else
            k(a2, 1) ? h2 = M[n2] : (o2++, h2 = M[a2.text], n2 = a2.text);
          if (!(o2 + h2 < s2.length))
            throw new Error("Path data ended short");
          for (let t3 = o2; t3 < o2 + h2; t3++) {
            const e3 = s2[t3];
            if (!k(e3, 1))
              throw new Error("Param not a number: " + n2 + "," + e3.text);
            r2[r2.length] = +e3.text;
          }
          if ("number" != typeof M[n2])
            throw new Error("Bad segment: " + n2);
          {
            const t3 = {
              key: n2,
              data: r2
            };
            e2.push(t3), o2 += h2, a2 = s2[o2], "M" === n2 && (n2 = "L"), "m" === n2 && (n2 = "l");
          }
        }
        return e2;
      }
      function m(t2) {
        let e2 = 0, s2 = 0, n2 = 0, o2 = 0;
        const a2 = [];
        for (const {key: h2, data: r2} of t2)
          switch (h2) {
            case "M":
              a2.push({
                key: "M",
                data: [...r2]
              }), [e2, s2] = r2, [n2, o2] = r2;
              break;
            case "m":
              e2 += r2[0], s2 += r2[1], a2.push({
                key: "M",
                data: [e2, s2]
              }), n2 = e2, o2 = s2;
              break;
            case "L":
              a2.push({
                key: "L",
                data: [...r2]
              }), [e2, s2] = r2;
              break;
            case "l":
              e2 += r2[0], s2 += r2[1], a2.push({
                key: "L",
                data: [e2, s2]
              });
              break;
            case "C":
              a2.push({
                key: "C",
                data: [...r2]
              }), e2 = r2[4], s2 = r2[5];
              break;
            case "c": {
              const t3 = r2.map((t4, n3) => n3 % 2 ? t4 + s2 : t4 + e2);
              a2.push({
                key: "C",
                data: t3
              }), e2 = t3[4], s2 = t3[5];
              break;
            }
            case "Q":
              a2.push({
                key: "Q",
                data: [...r2]
              }), e2 = r2[2], s2 = r2[3];
              break;
            case "q": {
              const t3 = r2.map((t4, n3) => n3 % 2 ? t4 + s2 : t4 + e2);
              a2.push({
                key: "Q",
                data: t3
              }), e2 = t3[2], s2 = t3[3];
              break;
            }
            case "A":
              a2.push({
                key: "A",
                data: [...r2]
              }), e2 = r2[5], s2 = r2[6];
              break;
            case "a":
              e2 += r2[5], s2 += r2[6], a2.push({
                key: "A",
                data: [r2[0], r2[1], r2[2], r2[3], r2[4], e2, s2]
              });
              break;
            case "H":
              a2.push({
                key: "H",
                data: [...r2]
              }), e2 = r2[0];
              break;
            case "h":
              e2 += r2[0], a2.push({
                key: "H",
                data: [e2]
              });
              break;
            case "V":
              a2.push({
                key: "V",
                data: [...r2]
              }), s2 = r2[0];
              break;
            case "v":
              s2 += r2[0], a2.push({
                key: "V",
                data: [s2]
              });
              break;
            case "S":
              a2.push({
                key: "S",
                data: [...r2]
              }), e2 = r2[2], s2 = r2[3];
              break;
            case "s": {
              const t3 = r2.map((t4, n3) => n3 % 2 ? t4 + s2 : t4 + e2);
              a2.push({
                key: "S",
                data: t3
              }), e2 = t3[2], s2 = t3[3];
              break;
            }
            case "T":
              a2.push({
                key: "T",
                data: [...r2]
              }), e2 = r2[0], s2 = r2[1];
              break;
            case "t":
              e2 += r2[0], s2 += r2[1], a2.push({
                key: "T",
                data: [e2, s2]
              });
              break;
            case "Z":
            case "z":
              a2.push({
                key: "Z",
                data: []
              }), e2 = n2, s2 = o2;
          }
        return a2;
      }
      function b(t2) {
        const e2 = [];
        let s2 = "", n2 = 0, o2 = 0, a2 = 0, h2 = 0, r2 = 0, i2 = 0;
        for (const {key: c2, data: l2} of t2) {
          switch (c2) {
            case "M":
              e2.push({
                key: "M",
                data: [...l2]
              }), [n2, o2] = l2, [a2, h2] = l2;
              break;
            case "C":
              e2.push({
                key: "C",
                data: [...l2]
              }), n2 = l2[4], o2 = l2[5], r2 = l2[2], i2 = l2[3];
              break;
            case "L":
              e2.push({
                key: "L",
                data: [...l2]
              }), [n2, o2] = l2;
              break;
            case "H":
              n2 = l2[0], e2.push({
                key: "L",
                data: [n2, o2]
              });
              break;
            case "V":
              o2 = l2[0], e2.push({
                key: "L",
                data: [n2, o2]
              });
              break;
            case "S": {
              let t3 = 0, a3 = 0;
              "C" === s2 || "S" === s2 ? (t3 = n2 + (n2 - r2), a3 = o2 + (o2 - i2)) : (t3 = n2, a3 = o2), e2.push({
                key: "C",
                data: [t3, a3, ...l2]
              }), r2 = l2[0], i2 = l2[1], n2 = l2[2], o2 = l2[3];
              break;
            }
            case "T": {
              const [t3, a3] = l2;
              let h3 = 0, c3 = 0;
              "Q" === s2 || "T" === s2 ? (h3 = n2 + (n2 - r2), c3 = o2 + (o2 - i2)) : (h3 = n2, c3 = o2);
              const u2 = n2 + 2 * (h3 - n2) / 3, p2 = o2 + 2 * (c3 - o2) / 3, f2 = t3 + 2 * (h3 - t3) / 3, d2 = a3 + 2 * (c3 - a3) / 3;
              e2.push({
                key: "C",
                data: [u2, p2, f2, d2, t3, a3]
              }), r2 = h3, i2 = c3, n2 = t3, o2 = a3;
              break;
            }
            case "Q": {
              const [t3, s3, a3, h3] = l2, c3 = n2 + 2 * (t3 - n2) / 3, u2 = o2 + 2 * (s3 - o2) / 3, p2 = a3 + 2 * (t3 - a3) / 3, f2 = h3 + 2 * (s3 - h3) / 3;
              e2.push({
                key: "C",
                data: [c3, u2, p2, f2, a3, h3]
              }), r2 = t3, i2 = s3, n2 = a3, o2 = h3;
              break;
            }
            case "A": {
              const t3 = Math.abs(l2[0]), s3 = Math.abs(l2[1]), a3 = l2[2], h3 = l2[3], r3 = l2[4], i3 = l2[5], c3 = l2[6];
              if (0 === t3 || 0 === s3)
                e2.push({
                  key: "C",
                  data: [n2, o2, i3, c3, i3, c3]
                }), n2 = i3, o2 = c3;
              else if (n2 !== i3 || o2 !== c3) {
                w(n2, o2, i3, c3, t3, s3, a3, h3, r3).forEach(function(t4) {
                  e2.push({
                    key: "C",
                    data: t4
                  });
                }), n2 = i3, o2 = c3;
              }
              break;
            }
            case "Z":
              e2.push({
                key: "Z",
                data: []
              }), n2 = a2, o2 = h2;
          }
          s2 = c2;
        }
        return e2;
      }
      function P(t2, e2, s2) {
        return [t2 * Math.cos(s2) - e2 * Math.sin(s2), t2 * Math.sin(s2) + e2 * Math.cos(s2)];
      }
      function w(t2, e2, s2, n2, o2, a2, h2, r2, i2, c2) {
        const l2 = (u2 = h2, Math.PI * u2 / 180);
        var u2;
        let p2 = [], f2 = 0, d2 = 0, g2 = 0, M2 = 0;
        if (c2)
          [f2, d2, g2, M2] = c2;
        else {
          [t2, e2] = P(t2, e2, -l2), [s2, n2] = P(s2, n2, -l2);
          const h3 = (t2 - s2) / 2, c3 = (e2 - n2) / 2;
          let u3 = h3 * h3 / (o2 * o2) + c3 * c3 / (a2 * a2);
          u3 > 1 && (u3 = Math.sqrt(u3), o2 *= u3, a2 *= u3);
          const p3 = o2 * o2, k3 = a2 * a2, y3 = p3 * k3 - p3 * c3 * c3 - k3 * h3 * h3, m3 = p3 * c3 * c3 + k3 * h3 * h3, b3 = (r2 === i2 ? -1 : 1) * Math.sqrt(Math.abs(y3 / m3));
          g2 = b3 * o2 * c3 / a2 + (t2 + s2) / 2, M2 = b3 * -a2 * h3 / o2 + (e2 + n2) / 2, f2 = Math.asin(parseFloat(((e2 - M2) / a2).toFixed(9))), d2 = Math.asin(parseFloat(((n2 - M2) / a2).toFixed(9))), t2 < g2 && (f2 = Math.PI - f2), s2 < g2 && (d2 = Math.PI - d2), f2 < 0 && (f2 = 2 * Math.PI + f2), d2 < 0 && (d2 = 2 * Math.PI + d2), i2 && f2 > d2 && (f2 -= 2 * Math.PI), !i2 && d2 > f2 && (d2 -= 2 * Math.PI);
        }
        let k2 = d2 - f2;
        if (Math.abs(k2) > 120 * Math.PI / 180) {
          const t3 = d2, e3 = s2, r3 = n2;
          d2 = i2 && d2 > f2 ? f2 + 120 * Math.PI / 180 * 1 : f2 + 120 * Math.PI / 180 * -1, p2 = w(s2 = g2 + o2 * Math.cos(d2), n2 = M2 + a2 * Math.sin(d2), e3, r3, o2, a2, h2, 0, i2, [d2, t3, g2, M2]);
        }
        k2 = d2 - f2;
        const y2 = Math.cos(f2), m2 = Math.sin(f2), b2 = Math.cos(d2), x2 = Math.sin(d2), v2 = Math.tan(k2 / 4), S2 = 4 / 3 * o2 * v2, O2 = 4 / 3 * a2 * v2, T2 = [t2, e2], I2 = [t2 + S2 * m2, e2 - O2 * y2], _2 = [s2 + S2 * x2, n2 - O2 * b2], C2 = [s2, n2];
        if (I2[0] = 2 * T2[0] - I2[0], I2[1] = 2 * T2[1] - I2[1], c2)
          return [I2, _2, C2].concat(p2);
        {
          p2 = [I2, _2, C2].concat(p2);
          const t3 = [];
          for (let e3 = 0; e3 < p2.length; e3 += 3) {
            const s3 = P(p2[e3][0], p2[e3][1], l2), n3 = P(p2[e3 + 1][0], p2[e3 + 1][1], l2), o3 = P(p2[e3 + 2][0], p2[e3 + 2][1], l2);
            t3.push([s3[0], s3[1], n3[0], n3[1], o3[0], o3[1]]);
          }
          return t3;
        }
      }
      const x = {
        randOffset: function(t2, e2) {
          return z(t2, e2);
        },
        randOffsetWithRange: function(t2, e2, s2) {
          return E(t2, e2, s2);
        },
        ellipse: function(t2, e2, s2, n2, o2) {
          const a2 = T(s2, n2, o2);
          return I(t2, e2, o2, a2).opset;
        },
        doubleLineOps: function(t2, e2, s2, n2, o2) {
          return A(t2, e2, s2, n2, o2);
        }
      };
      function v(t2, e2, s2, n2, o2) {
        return {
          type: "path",
          ops: A(t2, e2, s2, n2, o2)
        };
      }
      function S(t2, e2, s2) {
        const n2 = (t2 || []).length;
        if (n2 > 2) {
          const o2 = [];
          for (let e3 = 0; e3 < n2 - 1; e3++)
            o2.push(...A(t2[e3][0], t2[e3][1], t2[e3 + 1][0], t2[e3 + 1][1], s2));
          return e2 && o2.push(...A(t2[n2 - 1][0], t2[n2 - 1][1], t2[0][0], t2[0][1], s2)), {
            type: "path",
            ops: o2
          };
        }
        return 2 === n2 ? v(t2[0][0], t2[0][1], t2[1][0], t2[1][1], s2) : {
          type: "path",
          ops: []
        };
      }
      function O(t2, e2, s2, n2, o2) {
        return function(t3, e3) {
          return S(t3, true, e3);
        }([[t2, e2], [t2 + s2, e2], [t2 + s2, e2 + n2], [t2, e2 + n2]], o2);
      }
      function T(t2, e2, s2) {
        const n2 = Math.sqrt(2 * Math.PI * Math.sqrt((Math.pow(t2 / 2, 2) + Math.pow(e2 / 2, 2)) / 2)), o2 = Math.max(s2.curveStepCount, s2.curveStepCount / Math.sqrt(200) * n2), a2 = 2 * Math.PI / o2;
        let h2 = Math.abs(t2 / 2), r2 = Math.abs(e2 / 2);
        const i2 = 1 - s2.curveFitting;
        return h2 += z(h2 * i2, s2), r2 += z(r2 * i2, s2), {
          increment: a2,
          rx: h2,
          ry: r2
        };
      }
      function I(t2, e2, s2, n2) {
        const [o2, a2] = q(n2.increment, t2, e2, n2.rx, n2.ry, 1, n2.increment * E(0.1, E(0.4, 1, s2), s2), s2), [h2] = q(n2.increment, t2, e2, n2.rx, n2.ry, 1.5, 0, s2), r2 = G(o2, null, s2), i2 = G(h2, null, s2);
        return {
          estimatedPoints: a2,
          opset: {
            type: "path",
            ops: r2.concat(i2)
          }
        };
      }
      function _(t2, e2, s2, n2, o2, a2, h2, r2, i2) {
        const c2 = t2, l2 = e2;
        let u2 = Math.abs(s2 / 2), p2 = Math.abs(n2 / 2);
        u2 += z(0.01 * u2, i2), p2 += z(0.01 * p2, i2);
        let f2 = o2, d2 = a2;
        for (; f2 < 0; )
          f2 += 2 * Math.PI, d2 += 2 * Math.PI;
        d2 - f2 > 2 * Math.PI && (f2 = 0, d2 = 2 * Math.PI);
        const g2 = 2 * Math.PI / i2.curveStepCount, M2 = Math.min(g2 / 2, (d2 - f2) / 2), k2 = F(M2, c2, l2, u2, p2, f2, d2, 1, i2), y2 = F(M2, c2, l2, u2, p2, f2, d2, 1.5, i2), m2 = k2.concat(y2);
        return h2 && (r2 ? m2.push(...A(c2, l2, c2 + u2 * Math.cos(f2), l2 + p2 * Math.sin(f2), i2), ...A(c2, l2, c2 + u2 * Math.cos(d2), l2 + p2 * Math.sin(d2), i2)) : m2.push({
          op: "lineTo",
          data: [c2, l2]
        }, {
          op: "lineTo",
          data: [c2 + u2 * Math.cos(f2), l2 + p2 * Math.sin(f2)]
        })), {
          type: "path",
          ops: m2
        };
      }
      function C(t2, e2) {
        const s2 = [];
        if (t2.length) {
          const n2 = e2.maxRandomnessOffset || 0, o2 = t2.length;
          if (o2 > 2) {
            s2.push({
              op: "move",
              data: [t2[0][0] + z(n2, e2), t2[0][1] + z(n2, e2)]
            });
            for (let a2 = 1; a2 < o2; a2++)
              s2.push({
                op: "lineTo",
                data: [t2[a2][0] + z(n2, e2), t2[a2][1] + z(n2, e2)]
              });
          }
        }
        return {
          type: "fillPath",
          ops: s2
        };
      }
      function W(t2, e2) {
        return function(t3, e3) {
          let s2 = t3.fillStyle || "hachure";
          if (!d[s2])
            switch (s2) {
              case "zigzag":
                d[s2] || (d[s2] = new c(e3));
                break;
              case "cross-hatch":
                d[s2] || (d[s2] = new l(e3));
                break;
              case "dots":
                d[s2] || (d[s2] = new u(e3));
                break;
              case "dashed":
                d[s2] || (d[s2] = new p(e3));
                break;
              case "zigzag-line":
                d[s2] || (d[s2] = new f(e3));
                break;
              case "hachure":
              default:
                s2 = "hachure", d[s2] || (d[s2] = new i(e3));
            }
          return d[s2];
        }(e2, x).fillPolygon(t2, e2);
      }
      function L(t2) {
        return t2.randomizer || (t2.randomizer = new g(t2.seed || 0)), t2.randomizer.next();
      }
      function E(t2, e2, s2, n2 = 1) {
        return s2.roughness * n2 * (L(s2) * (e2 - t2) + t2);
      }
      function z(t2, e2, s2 = 1) {
        return E(-t2, t2, e2, s2);
      }
      function A(t2, e2, s2, n2, o2) {
        const a2 = R(t2, e2, s2, n2, o2, true, false), h2 = R(t2, e2, s2, n2, o2, true, true);
        return a2.concat(h2);
      }
      function R(t2, e2, s2, n2, o2, a2, h2) {
        const r2 = Math.pow(t2 - s2, 2) + Math.pow(e2 - n2, 2), i2 = Math.sqrt(r2);
        let c2 = 1;
        c2 = i2 < 200 ? 1 : i2 > 500 ? 0.4 : -0.0016668 * i2 + 1.233334;
        let l2 = o2.maxRandomnessOffset || 0;
        l2 * l2 * 100 > r2 && (l2 = i2 / 10);
        const u2 = l2 / 2, p2 = 0.2 + 0.2 * L(o2);
        let f2 = o2.bowing * o2.maxRandomnessOffset * (n2 - e2) / 200, d2 = o2.bowing * o2.maxRandomnessOffset * (t2 - s2) / 200;
        f2 = z(f2, o2, c2), d2 = z(d2, o2, c2);
        const g2 = [], M2 = () => z(u2, o2, c2), k2 = () => z(l2, o2, c2);
        return a2 && (h2 ? g2.push({
          op: "move",
          data: [t2 + M2(), e2 + M2()]
        }) : g2.push({
          op: "move",
          data: [t2 + z(l2, o2, c2), e2 + z(l2, o2, c2)]
        })), h2 ? g2.push({
          op: "bcurveTo",
          data: [f2 + t2 + (s2 - t2) * p2 + M2(), d2 + e2 + (n2 - e2) * p2 + M2(), f2 + t2 + 2 * (s2 - t2) * p2 + M2(), d2 + e2 + 2 * (n2 - e2) * p2 + M2(), s2 + M2(), n2 + M2()]
        }) : g2.push({
          op: "bcurveTo",
          data: [f2 + t2 + (s2 - t2) * p2 + k2(), d2 + e2 + (n2 - e2) * p2 + k2(), f2 + t2 + 2 * (s2 - t2) * p2 + k2(), d2 + e2 + 2 * (n2 - e2) * p2 + k2(), s2 + k2(), n2 + k2()]
        }), g2;
      }
      function $2(t2, e2, s2) {
        const n2 = [];
        n2.push([t2[0][0] + z(e2, s2), t2[0][1] + z(e2, s2)]), n2.push([t2[0][0] + z(e2, s2), t2[0][1] + z(e2, s2)]);
        for (let o2 = 1; o2 < t2.length; o2++)
          n2.push([t2[o2][0] + z(e2, s2), t2[o2][1] + z(e2, s2)]), o2 === t2.length - 1 && n2.push([t2[o2][0] + z(e2, s2), t2[o2][1] + z(e2, s2)]);
        return G(n2, null, s2);
      }
      function G(t2, e2, s2) {
        const n2 = t2.length, o2 = [];
        if (n2 > 3) {
          const a2 = [], h2 = 1 - s2.curveTightness;
          o2.push({
            op: "move",
            data: [t2[1][0], t2[1][1]]
          });
          for (let e3 = 1; e3 + 2 < n2; e3++) {
            const s3 = t2[e3];
            a2[0] = [s3[0], s3[1]], a2[1] = [s3[0] + (h2 * t2[e3 + 1][0] - h2 * t2[e3 - 1][0]) / 6, s3[1] + (h2 * t2[e3 + 1][1] - h2 * t2[e3 - 1][1]) / 6], a2[2] = [t2[e3 + 1][0] + (h2 * t2[e3][0] - h2 * t2[e3 + 2][0]) / 6, t2[e3 + 1][1] + (h2 * t2[e3][1] - h2 * t2[e3 + 2][1]) / 6], a2[3] = [t2[e3 + 1][0], t2[e3 + 1][1]], o2.push({
              op: "bcurveTo",
              data: [a2[1][0], a2[1][1], a2[2][0], a2[2][1], a2[3][0], a2[3][1]]
            });
          }
          if (e2 && 2 === e2.length) {
            const t3 = s2.maxRandomnessOffset;
            o2.push({
              op: "lineTo",
              data: [e2[0] + z(t3, s2), e2[1] + z(t3, s2)]
            });
          }
        } else
          3 === n2 ? (o2.push({
            op: "move",
            data: [t2[1][0], t2[1][1]]
          }), o2.push({
            op: "bcurveTo",
            data: [t2[1][0], t2[1][1], t2[2][0], t2[2][1], t2[2][0], t2[2][1]]
          })) : 2 === n2 && o2.push(...A(t2[0][0], t2[0][1], t2[1][0], t2[1][1], s2));
        return o2;
      }
      function q(t2, e2, s2, n2, o2, a2, h2, r2) {
        const i2 = [], c2 = [], l2 = z(0.5, r2) - Math.PI / 2;
        c2.push([z(a2, r2) + e2 + 0.9 * n2 * Math.cos(l2 - t2), z(a2, r2) + s2 + 0.9 * o2 * Math.sin(l2 - t2)]);
        for (let h3 = l2; h3 < 2 * Math.PI + l2 - 0.01; h3 += t2) {
          const t3 = [z(a2, r2) + e2 + n2 * Math.cos(h3), z(a2, r2) + s2 + o2 * Math.sin(h3)];
          i2.push(t3), c2.push(t3);
        }
        return c2.push([z(a2, r2) + e2 + n2 * Math.cos(l2 + 2 * Math.PI + 0.5 * h2), z(a2, r2) + s2 + o2 * Math.sin(l2 + 2 * Math.PI + 0.5 * h2)]), c2.push([z(a2, r2) + e2 + 0.98 * n2 * Math.cos(l2 + h2), z(a2, r2) + s2 + 0.98 * o2 * Math.sin(l2 + h2)]), c2.push([z(a2, r2) + e2 + 0.9 * n2 * Math.cos(l2 + 0.5 * h2), z(a2, r2) + s2 + 0.9 * o2 * Math.sin(l2 + 0.5 * h2)]), [c2, i2];
      }
      function F(t2, e2, s2, n2, o2, a2, h2, r2, i2) {
        const c2 = a2 + z(0.1, i2), l2 = [];
        l2.push([z(r2, i2) + e2 + 0.9 * n2 * Math.cos(c2 - t2), z(r2, i2) + s2 + 0.9 * o2 * Math.sin(c2 - t2)]);
        for (let a3 = c2; a3 <= h2; a3 += t2)
          l2.push([z(r2, i2) + e2 + n2 * Math.cos(a3), z(r2, i2) + s2 + o2 * Math.sin(a3)]);
        return l2.push([e2 + n2 * Math.cos(h2), s2 + o2 * Math.sin(h2)]), l2.push([e2 + n2 * Math.cos(h2), s2 + o2 * Math.sin(h2)]), G(l2, null, i2);
      }
      function N(t2, e2, s2, n2, o2, a2, h2, r2) {
        const i2 = [], c2 = [r2.maxRandomnessOffset || 1, (r2.maxRandomnessOffset || 1) + 0.3];
        let l2 = [0, 0];
        for (let u2 = 0; u2 < 2; u2++)
          0 === u2 ? i2.push({
            op: "move",
            data: [h2[0], h2[1]]
          }) : i2.push({
            op: "move",
            data: [h2[0] + z(c2[0], r2), h2[1] + z(c2[0], r2)]
          }), l2 = [o2 + z(c2[u2], r2), a2 + z(c2[u2], r2)], i2.push({
            op: "bcurveTo",
            data: [t2 + z(c2[u2], r2), e2 + z(c2[u2], r2), s2 + z(c2[u2], r2), n2 + z(c2[u2], r2), l2[0], l2[1]]
          });
        return i2;
      }
      function Z(t2) {
        return [...t2];
      }
      function D(t2, e2) {
        return Math.pow(t2[0] - e2[0], 2) + Math.pow(t2[1] - e2[1], 2);
      }
      function Q(t2, e2, s2) {
        const n2 = D(e2, s2);
        if (0 === n2)
          return D(t2, e2);
        let o2 = ((t2[0] - e2[0]) * (s2[0] - e2[0]) + (t2[1] - e2[1]) * (s2[1] - e2[1])) / n2;
        return o2 = Math.max(0, Math.min(1, o2)), D(t2, j(e2, s2, o2));
      }
      function j(t2, e2, s2) {
        return [t2[0] + (e2[0] - t2[0]) * s2, t2[1] + (e2[1] - t2[1]) * s2];
      }
      function H(t2, e2, s2, n2) {
        const o2 = n2 || [];
        if (function(t3, e3) {
          const s3 = t3[e3 + 0], n3 = t3[e3 + 1], o3 = t3[e3 + 2], a3 = t3[e3 + 3];
          let h3 = 3 * n3[0] - 2 * s3[0] - a3[0];
          h3 *= h3;
          let r2 = 3 * n3[1] - 2 * s3[1] - a3[1];
          r2 *= r2;
          let i2 = 3 * o3[0] - 2 * a3[0] - s3[0];
          i2 *= i2;
          let c2 = 3 * o3[1] - 2 * a3[1] - s3[1];
          return c2 *= c2, h3 < i2 && (h3 = i2), r2 < c2 && (r2 = c2), h3 + r2;
        }(t2, e2) < s2) {
          const s3 = t2[e2 + 0];
          if (o2.length) {
            (a2 = o2[o2.length - 1], h2 = s3, Math.sqrt(D(a2, h2))) > 1 && o2.push(s3);
          } else
            o2.push(s3);
          o2.push(t2[e2 + 3]);
        } else {
          const n3 = 0.5, a3 = t2[e2 + 0], h3 = t2[e2 + 1], r2 = t2[e2 + 2], i2 = t2[e2 + 3], c2 = j(a3, h3, n3), l2 = j(h3, r2, n3), u2 = j(r2, i2, n3), p2 = j(c2, l2, n3), f2 = j(l2, u2, n3), d2 = j(p2, f2, n3);
          H([a3, c2, p2, d2], 0, s2, o2), H([d2, f2, u2, i2], 0, s2, o2);
        }
        var a2, h2;
        return o2;
      }
      function V(t2, e2) {
        return B(t2, 0, t2.length, e2);
      }
      function B(t2, e2, s2, n2, o2) {
        const a2 = o2 || [], h2 = t2[e2], r2 = t2[s2 - 1];
        let i2 = 0, c2 = 1;
        for (let n3 = e2 + 1; n3 < s2 - 1; ++n3) {
          const e3 = Q(t2[n3], h2, r2);
          e3 > i2 && (i2 = e3, c2 = n3);
        }
        return Math.sqrt(i2) > n2 ? (B(t2, e2, c2 + 1, n2, a2), B(t2, c2, s2, n2, a2)) : (a2.length || a2.push(h2), a2.push(r2)), a2;
      }
      function X(t2, e2 = 0.15, s2) {
        const n2 = [], o2 = (t2.length - 1) / 3;
        for (let s3 = 0; s3 < o2; s3++) {
          H(t2, 3 * s3, e2, n2);
        }
        return s2 && s2 > 0 ? B(n2, 0, n2.length, s2) : n2;
      }
      const J = "none";
      class K {
        constructor(t2) {
          this.defaultOptions = {
            maxRandomnessOffset: 2,
            roughness: 1,
            bowing: 1,
            stroke: "#000",
            strokeWidth: 1,
            curveTightness: 0,
            curveFitting: 0.95,
            curveStepCount: 9,
            fillStyle: "hachure",
            fillWeight: -1,
            hachureAngle: -41,
            hachureGap: -1,
            dashOffset: -1,
            dashGap: -1,
            zigzagOffset: -1,
            seed: 0,
            combineNestedSvgPaths: false
          }, this.config = t2 || {}, this.config.options && (this.defaultOptions = this._o(this.config.options));
        }
        static newSeed() {
          return Math.floor(Math.random() * 2 ** 31);
        }
        _o(t2) {
          return t2 ? Object.assign({}, this.defaultOptions, t2) : this.defaultOptions;
        }
        _d(t2, e2, s2) {
          return {
            shape: t2,
            sets: e2 || [],
            options: s2 || this.defaultOptions
          };
        }
        line(t2, e2, s2, n2, o2) {
          const a2 = this._o(o2);
          return this._d("line", [v(t2, e2, s2, n2, a2)], a2);
        }
        rectangle(t2, e2, s2, n2, o2) {
          const a2 = this._o(o2), h2 = [], r2 = O(t2, e2, s2, n2, a2);
          if (a2.fill) {
            const o3 = [[t2, e2], [t2 + s2, e2], [t2 + s2, e2 + n2], [t2, e2 + n2]];
            "solid" === a2.fillStyle ? h2.push(C(o3, a2)) : h2.push(W(o3, a2));
          }
          return a2.stroke !== J && h2.push(r2), this._d("rectangle", h2, a2);
        }
        ellipse(t2, e2, s2, n2, o2) {
          const a2 = this._o(o2), h2 = [], r2 = T(s2, n2, a2), i2 = I(t2, e2, a2, r2);
          if (a2.fill)
            if ("solid" === a2.fillStyle) {
              const s3 = I(t2, e2, a2, r2).opset;
              s3.type = "fillPath", h2.push(s3);
            } else
              h2.push(W(i2.estimatedPoints, a2));
          return a2.stroke !== J && h2.push(i2.opset), this._d("ellipse", h2, a2);
        }
        circle(t2, e2, s2, n2) {
          const o2 = this.ellipse(t2, e2, s2, s2, n2);
          return o2.shape = "circle", o2;
        }
        linearPath(t2, e2) {
          const s2 = this._o(e2);
          return this._d("linearPath", [S(t2, false, s2)], s2);
        }
        arc(t2, e2, s2, n2, o2, a2, h2 = false, r2) {
          const i2 = this._o(r2), c2 = [], l2 = _(t2, e2, s2, n2, o2, a2, h2, true, i2);
          if (h2 && i2.fill)
            if ("solid" === i2.fillStyle) {
              const h3 = _(t2, e2, s2, n2, o2, a2, true, false, i2);
              h3.type = "fillPath", c2.push(h3);
            } else
              c2.push(function(t3, e3, s3, n3, o3, a3, h3) {
                const r3 = t3, i3 = e3;
                let c3 = Math.abs(s3 / 2), l3 = Math.abs(n3 / 2);
                c3 += z(0.01 * c3, h3), l3 += z(0.01 * l3, h3);
                let u2 = o3, p2 = a3;
                for (; u2 < 0; )
                  u2 += 2 * Math.PI, p2 += 2 * Math.PI;
                p2 - u2 > 2 * Math.PI && (u2 = 0, p2 = 2 * Math.PI);
                const f2 = (p2 - u2) / h3.curveStepCount, d2 = [];
                for (let t4 = u2; t4 <= p2; t4 += f2)
                  d2.push([r3 + c3 * Math.cos(t4), i3 + l3 * Math.sin(t4)]);
                return d2.push([r3 + c3 * Math.cos(p2), i3 + l3 * Math.sin(p2)]), d2.push([r3, i3]), W(d2, h3);
              }(t2, e2, s2, n2, o2, a2, i2));
          return i2.stroke !== J && c2.push(l2), this._d("arc", c2, i2);
        }
        curve(t2, e2) {
          const s2 = this._o(e2), n2 = [], o2 = function(t3, e3) {
            const s3 = $2(t3, 1 * (1 + 0.2 * e3.roughness), e3), n3 = $2(t3, 1.5 * (1 + 0.22 * e3.roughness), e3);
            return {
              type: "path",
              ops: s3.concat(n3)
            };
          }(t2, s2);
          if (s2.fill && s2.fill !== J && t2.length >= 3) {
            const e3 = X(function(t3, e4 = 0) {
              const s3 = t3.length;
              if (s3 < 3)
                throw new Error("A curve must have at least three points.");
              const n3 = [];
              if (3 === s3)
                n3.push(Z(t3[0]), Z(t3[1]), Z(t3[2]), Z(t3[2]));
              else {
                const s4 = [];
                s4.push(t3[0], t3[0]);
                for (let e5 = 1; e5 < t3.length; e5++)
                  s4.push(t3[e5]), e5 === t3.length - 1 && s4.push(t3[e5]);
                const o3 = [], a2 = 1 - e4;
                n3.push(Z(s4[0]));
                for (let t4 = 1; t4 + 2 < s4.length; t4++) {
                  const e5 = s4[t4];
                  o3[0] = [e5[0], e5[1]], o3[1] = [e5[0] + (a2 * s4[t4 + 1][0] - a2 * s4[t4 - 1][0]) / 6, e5[1] + (a2 * s4[t4 + 1][1] - a2 * s4[t4 - 1][1]) / 6], o3[2] = [s4[t4 + 1][0] + (a2 * s4[t4][0] - a2 * s4[t4 + 2][0]) / 6, s4[t4 + 1][1] + (a2 * s4[t4][1] - a2 * s4[t4 + 2][1]) / 6], o3[3] = [s4[t4 + 1][0], s4[t4 + 1][1]], n3.push(o3[1], o3[2], o3[3]);
                }
              }
              return n3;
            }(t2), 10, (1 + s2.roughness) / 2);
            "solid" === s2.fillStyle ? n2.push(C(e3, s2)) : n2.push(W(e3, s2));
          }
          return s2.stroke !== J && n2.push(o2), this._d("curve", n2, s2);
        }
        polygon(t2, e2) {
          const s2 = this._o(e2), n2 = [], o2 = S(t2, true, s2);
          return s2.fill && ("solid" === s2.fillStyle ? n2.push(C(t2, s2)) : n2.push(W(t2, s2))), s2.stroke !== J && n2.push(o2), this._d("polygon", n2, s2);
        }
        path(t2, e2) {
          const s2 = this._o(e2), n2 = [];
          if (!t2)
            return this._d("path", n2, s2);
          t2 = (t2 || "").replace(/\n/g, " ").replace(/(-\s)/g, "-").replace("/(ss)/g", " ");
          const o2 = s2.fill && "transparent" !== s2.fill && s2.fill !== J, a2 = s2.stroke !== J, h2 = !!(s2.simplification && s2.simplification < 1), r2 = function(t3, e3, s3) {
            const n3 = b(m(y(t3))), o3 = [];
            let a3 = [], h3 = [0, 0], r3 = [];
            const i2 = () => {
              r3.length >= 4 && a3.push(...X(r3, e3)), r3 = [];
            }, c2 = () => {
              i2(), a3.length && (o3.push(a3), a3 = []);
            };
            for (const {key: t4, data: e4} of n3)
              switch (t4) {
                case "M":
                  c2(), h3 = [e4[0], e4[1]], a3.push(h3);
                  break;
                case "L":
                  i2(), a3.push([e4[0], e4[1]]);
                  break;
                case "C":
                  if (!r3.length) {
                    const t5 = a3.length ? a3[a3.length - 1] : h3;
                    r3.push([t5[0], t5[1]]);
                  }
                  r3.push([e4[0], e4[1]]), r3.push([e4[2], e4[3]]), r3.push([e4[4], e4[5]]);
                  break;
                case "Z":
                  i2(), a3.push([h3[0], h3[1]]);
              }
            if (c2(), !s3)
              return o3;
            const l2 = [];
            for (const t4 of o3) {
              const e4 = V(t4, s3);
              e4.length && l2.push(e4);
            }
            return l2;
          }(t2, 1, h2 ? 4 - 4 * s2.simplification : (1 + s2.roughness) / 2);
          if (o2)
            if (s2.combineNestedSvgPaths) {
              const t3 = [];
              r2.forEach((e3) => t3.push(...e3)), "solid" === s2.fillStyle ? n2.push(C(t3, s2)) : n2.push(W(t3, s2));
            } else
              r2.forEach((t3) => {
                "solid" === s2.fillStyle ? n2.push(C(t3, s2)) : n2.push(W(t3, s2));
              });
          return a2 && (h2 ? r2.forEach((t3) => {
            n2.push(S(t3, false, s2));
          }) : n2.push(function(t3, e3) {
            const s3 = b(m(y(t3))), n3 = [];
            let o3 = [0, 0], a3 = [0, 0];
            for (const {key: t4, data: h3} of s3)
              switch (t4) {
                case "M": {
                  const t5 = 1 * (e3.maxRandomnessOffset || 0);
                  n3.push({
                    op: "move",
                    data: h3.map((s4) => s4 + z(t5, e3))
                  }), a3 = [h3[0], h3[1]], o3 = [h3[0], h3[1]];
                  break;
                }
                case "L":
                  n3.push(...A(a3[0], a3[1], h3[0], h3[1], e3)), a3 = [h3[0], h3[1]];
                  break;
                case "C": {
                  const [t5, s4, o4, r3, i2, c2] = h3;
                  n3.push(...N(t5, s4, o4, r3, i2, c2, a3, e3)), a3 = [i2, c2];
                  break;
                }
                case "Z":
                  n3.push(...A(a3[0], a3[1], o3[0], o3[1], e3)), a3 = [o3[0], o3[1]];
              }
            return {
              type: "path",
              ops: n3
            };
          }(t2, s2))), this._d("path", n2, s2);
        }
        opsToPath(t2) {
          let e2 = "";
          for (const s2 of t2.ops) {
            const t3 = s2.data;
            switch (s2.op) {
              case "move":
                e2 += `M${t3[0]} ${t3[1]} `;
                break;
              case "bcurveTo":
                e2 += `C${t3[0]} ${t3[1]}, ${t3[2]} ${t3[3]}, ${t3[4]} ${t3[5]} `;
                break;
              case "lineTo":
                e2 += `L${t3[0]} ${t3[1]} `;
            }
          }
          return e2.trim();
        }
        toPaths(t2) {
          const e2 = t2.sets || [], s2 = t2.options || this.defaultOptions, n2 = [];
          for (const t3 of e2) {
            let e3 = null;
            switch (t3.type) {
              case "path":
                e3 = {
                  d: this.opsToPath(t3),
                  stroke: s2.stroke,
                  strokeWidth: s2.strokeWidth,
                  fill: J
                };
                break;
              case "fillPath":
                e3 = {
                  d: this.opsToPath(t3),
                  stroke: J,
                  strokeWidth: 0,
                  fill: s2.fill || J
                };
                break;
              case "fillSketch":
                e3 = this.fillSketch(t3, s2);
            }
            e3 && n2.push(e3);
          }
          return n2;
        }
        fillSketch(t2, e2) {
          let s2 = e2.fillWeight;
          return s2 < 0 && (s2 = e2.strokeWidth / 2), {
            d: this.opsToPath(t2),
            stroke: e2.fill || J,
            strokeWidth: s2,
            fill: J
          };
        }
      }
      class U {
        constructor(t2, e2) {
          this.canvas = t2, this.ctx = this.canvas.getContext("2d"), this.gen = new K(e2);
        }
        draw(t2) {
          const e2 = t2.sets || [], s2 = t2.options || this.getDefaultOptions(), n2 = this.ctx;
          for (const o2 of e2)
            switch (o2.type) {
              case "path":
                n2.save(), n2.strokeStyle = "none" === s2.stroke ? "transparent" : s2.stroke, n2.lineWidth = s2.strokeWidth, this._drawToContext(n2, o2), n2.restore();
                break;
              case "fillPath":
                n2.save(), n2.fillStyle = s2.fill || "";
                const e3 = "curve" === t2.shape || "polygon" === t2.shape ? "evenodd" : "nonzero";
                this._drawToContext(n2, o2, e3), n2.restore();
                break;
              case "fillSketch":
                this.fillSketch(n2, o2, s2);
            }
        }
        fillSketch(t2, e2, s2) {
          let n2 = s2.fillWeight;
          n2 < 0 && (n2 = s2.strokeWidth / 2), t2.save(), t2.strokeStyle = s2.fill || "", t2.lineWidth = n2, this._drawToContext(t2, e2), t2.restore();
        }
        _drawToContext(t2, e2, s2 = "nonzero") {
          t2.beginPath();
          for (const s3 of e2.ops) {
            const e3 = s3.data;
            switch (s3.op) {
              case "move":
                t2.moveTo(e3[0], e3[1]);
                break;
              case "bcurveTo":
                t2.bezierCurveTo(e3[0], e3[1], e3[2], e3[3], e3[4], e3[5]);
                break;
              case "lineTo":
                t2.lineTo(e3[0], e3[1]);
            }
          }
          "fillPath" === e2.type ? t2.fill(s2) : t2.stroke();
        }
        get generator() {
          return this.gen;
        }
        getDefaultOptions() {
          return this.gen.defaultOptions;
        }
        line(t2, e2, s2, n2, o2) {
          const a2 = this.gen.line(t2, e2, s2, n2, o2);
          return this.draw(a2), a2;
        }
        rectangle(t2, e2, s2, n2, o2) {
          const a2 = this.gen.rectangle(t2, e2, s2, n2, o2);
          return this.draw(a2), a2;
        }
        ellipse(t2, e2, s2, n2, o2) {
          const a2 = this.gen.ellipse(t2, e2, s2, n2, o2);
          return this.draw(a2), a2;
        }
        circle(t2, e2, s2, n2) {
          const o2 = this.gen.circle(t2, e2, s2, n2);
          return this.draw(o2), o2;
        }
        linearPath(t2, e2) {
          const s2 = this.gen.linearPath(t2, e2);
          return this.draw(s2), s2;
        }
        polygon(t2, e2) {
          const s2 = this.gen.polygon(t2, e2);
          return this.draw(s2), s2;
        }
        arc(t2, e2, s2, n2, o2, a2, h2 = false, r2) {
          const i2 = this.gen.arc(t2, e2, s2, n2, o2, a2, h2, r2);
          return this.draw(i2), i2;
        }
        curve(t2, e2) {
          const s2 = this.gen.curve(t2, e2);
          return this.draw(s2), s2;
        }
        path(t2, e2) {
          const s2 = this.gen.path(t2, e2);
          return this.draw(s2), s2;
        }
      }
      const Y = "http://www.w3.org/2000/svg";
      class tt {
        constructor(t2, e2) {
          this.svg = t2, this.gen = new K(e2);
        }
        draw(t2) {
          const e2 = t2.sets || [], s2 = t2.options || this.getDefaultOptions(), n2 = this.svg.ownerDocument || window.document, o2 = n2.createElementNS(Y, "g");
          for (const t3 of e2) {
            let e3 = null;
            switch (t3.type) {
              case "path":
                e3 = n2.createElementNS(Y, "path"), e3.setAttribute("d", this.opsToPath(t3)), e3.style.stroke = s2.stroke, e3.style.strokeWidth = s2.strokeWidth + "", e3.style.fill = "none";
                break;
              case "fillPath":
                e3 = n2.createElementNS(Y, "path"), e3.setAttribute("d", this.opsToPath(t3)), e3.style.stroke = "none", e3.style.strokeWidth = "0", e3.style.fill = s2.fill || "";
                break;
              case "fillSketch":
                e3 = this.fillSketch(n2, t3, s2);
            }
            e3 && o2.appendChild(e3);
          }
          return o2;
        }
        fillSketch(t2, e2, s2) {
          let n2 = s2.fillWeight;
          n2 < 0 && (n2 = s2.strokeWidth / 2);
          const o2 = t2.createElementNS(Y, "path");
          return o2.setAttribute("d", this.opsToPath(e2)), o2.style.stroke = s2.fill || "", o2.style.strokeWidth = n2 + "", o2.style.fill = "none", o2;
        }
        get generator() {
          return this.gen;
        }
        getDefaultOptions() {
          return this.gen.defaultOptions;
        }
        opsToPath(t2) {
          return this.gen.opsToPath(t2);
        }
        line(t2, e2, s2, n2, o2) {
          const a2 = this.gen.line(t2, e2, s2, n2, o2);
          return this.draw(a2);
        }
        rectangle(t2, e2, s2, n2, o2) {
          const a2 = this.gen.rectangle(t2, e2, s2, n2, o2);
          return this.draw(a2);
        }
        ellipse(t2, e2, s2, n2, o2) {
          const a2 = this.gen.ellipse(t2, e2, s2, n2, o2);
          return this.draw(a2);
        }
        circle(t2, e2, s2, n2) {
          const o2 = this.gen.circle(t2, e2, s2, n2);
          return this.draw(o2);
        }
        linearPath(t2, e2) {
          const s2 = this.gen.linearPath(t2, e2);
          return this.draw(s2);
        }
        polygon(t2, e2) {
          const s2 = this.gen.polygon(t2, e2);
          return this.draw(s2);
        }
        arc(t2, e2, s2, n2, o2, a2, h2 = false, r2) {
          const i2 = this.gen.arc(t2, e2, s2, n2, o2, a2, h2, r2);
          return this.draw(i2);
        }
        curve(t2, e2) {
          const s2 = this.gen.curve(t2, e2);
          return this.draw(s2);
        }
        path(t2, e2) {
          const s2 = this.gen.path(t2, e2);
          return this.draw(s2);
        }
      }
      var et = {
        canvas: (t2, e2) => new U(t2, e2),
        svg: (t2, e2) => new tt(t2, e2),
        generator: (t2) => new K(t2),
        newSeed: () => K.newSeed()
      };
      const default2 = et;

      // src/module/ClockTab.ts
      class ClockSidebarTab extends SidebarTab {
        constructor(options) {
          super(options);
          this.rough = [];
          this.data = {
            clocks: []
          };
          this.editStatus = false;
          this.rough = [];
          if (!ui[MODULE_NAME]) {
            ui[MODULE_NAME] = this;
          }
        }
        static get defaultOptions() {
          return mergeObject(super.defaultOptions, {
            id: MODULE_NAME,
            template: `modules/${MODULE_NAME}/templates/sidebar-tab.html`,
            title: "Clocks",
            scrollContainer: null,
            stream: false,
            classes: [MODULE_NAME]
          });
        }
        getData() {
          const data = super.getData();
          const clocks3 = Clock2.getClocks();
          const payload = {
            ...data,
            clocks: clocks3.map((c2, idx) => generateClockTemplatePayload({
              segments: c2.segments,
              size: 300,
              ticks: c2.ticks,
              id: Number(c2._id),
              title: c2.title,
              edit: this.data.clocks[idx]?.edit ?? false
            }))
          };
          this.data = payload;
          return payload;
        }
        render(force, options) {
          return super.render(force, options);
        }
        async _renderInner(data, options) {
          const el = await super._renderInner(data, options);
          this._drawClocks(el);
          return el;
        }
        _drawClocks(el) {
          return $(el).find("svg").each((idx, el2) => {
            const roughSvg = default2.svg(el2);
            this.rough[idx] = roughSvg;
            const clock = this.data.clocks[idx];
            const degreesPerSegment = 360 / clock.segments;
            const center = this.position.width / 2;
            const size = this.position.width - this.position.width / 20;
            el2.append(roughSvg.circle(center, center, size, {
              seed: clock.id,
              fill: "white",
              fillStyle: "solid"
            }), ...Array(clock.segments).fill(void 0).flatMap((_2, idx2) => {
              return [roughSvg.arc(center, center, size, size, toRadians(idx2 * degreesPerSegment), toRadians((idx2 + 1) * degreesPerSegment - 1), true, {
                roughness: 2,
                seed: clock.id,
                fill: clock.ticks > idx2 ? "tomato" : "transparent",
                fillStyle: "zigzag",
                fillWeight: 2.5,
                zigzagOffset: 8,
                hachureGap: 8
              }), roughSvg.arc(center, center, size, size, toRadians(idx2 * degreesPerSegment), toRadians((idx2 + 1) * degreesPerSegment - 1), true, {
                roughness: 0,
                seed: clock.id,
                fill: "transparent",
                fillStyle: "solid",
                stroke: "transparent"
              })];
            }));
          });
        }
        activateListeners(html) {
          Hooks.on(CLOCKS_HOOKS.clockSettingsUpdate, () => this.render(true, {}));
          if (!Clock2.userHasEditPermissions) {
            return;
          }
          super.activateListeners(html);
          const clocks3 = $(html).find("#clock-log").find("li.clock");
          $(this.element).find("button[role=create]").click(() => {
            Clock2.createClock();
          });
          $(this.element).find("button[role=reset]").click(() => {
            Clock2.resetClocks();
          });
          this._activeOnClickClockSegment(clocks3);
          this._activateOnClickEdit(clocks3);
        }
        _activeOnClickClockSegment(clocks3) {
          clocks3.each((idx, el) => {
            const {segments, id, ticks: currentTicks} = el.dataset;
            $(el).find("svg > g:odd").css("pointer-events", "none");
            $(el).find("svg > g:even:not(:first-child)").css("visibility", "hidden").each((idx2, el2) => {
              $(el2).click(() => {
                let ticks = idx2 + 1;
                if (ticks === Number(currentTicks)) {
                  ticks = idx2;
                }
                Clock2.setClock(Number(id), {
                  ticks
                });
              });
            });
          });
        }
        _activateOnClickEdit(clocks3) {
          clocks3.each((idx, clockEl) => {
            const {segments, id} = clockEl.dataset;
            $(clockEl).find("button[role=edit]").click((ev) => {
              const edit = this.data?.clocks[idx]?.edit ?? false;
              if (!edit) {
                $(clockEl).find("aside").slideDown();
              } else {
                $(clockEl).find("aside").slideUp();
              }
              this.data.clocks[idx].edit = !edit;
              this.render(true, {});
            });
            $(clockEl).find('input[name="title"]').blur((event) => {
              Clock2.setClock(Number(id), {
                title: event.target.value
              });
            });
            $(clockEl).find("button[role=plus]").click((ev) => {
              Clock2.setClock(Number(id), {
                segments: Number(segments) + 1
              });
            });
            $(clockEl).find("button[role=minus]").click((ev) => {
              Clock2.setClock(Number(id), {
                segments: Number(segments) - 1
              });
            });
          });
        }
      }

      // src/progressclocks.ts
      const debug = false;
      Hooks.once("init", async function() {
        console.log(`${MODULE_NAME} | Initializing Progress Clocks module`);
        registerSettings();
        await preloadTemplates2();
        ui[MODULE_NAME] = new ClockSidebarTab({});
        const _origSidebarRender = Sidebar.prototype._render;
        Sidebar.prototype._render = async function(...args) {
          await _origSidebarRender.call(this, ...args);
          await ui[MODULE_NAME]._render(true, {});
        };
        const _origDefaultOptions = Sidebar.defaultOptions;
        Sidebar.__defineGetter__("defaultOptions", function() {
          return mergeObject(_origDefaultOptions, {
            template: `modules/${MODULE_NAME}/templates/sidebar-with-clocks.html`,
            width: Number(_origDefaultOptions.width) + 30
          });
        });
      });
      if (debug) {
        window.createClock = Clock2.createClock;
        window.resetClocks = Clock2.resetClocks;
        window.getClocks = Clock2.getClocks;
      }
    },

    1(exports, module) {
      // node_modules/lodash.update/index.js
      var FUNC_ERROR_TEXT = "Expected a function";
      var HASH_UNDEFINED = "__lodash_hash_undefined__";
      var INFINITY = 1 / 0, MAX_SAFE_INTEGER = 9007199254740991;
      var funcTag = "[object Function]", genTag = "[object GeneratorFunction]", symbolTag = "[object Symbol]";
      var reIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/, reIsPlainProp = /^\w*$/, reLeadingDot = /^\./, rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;
      var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;
      var reEscapeChar = /\\(\\)?/g;
      var reIsHostCtor = /^\[object .+?Constructor\]$/;
      var reIsUint = /^(?:0|[1-9]\d*)$/;
      var freeGlobal = typeof window == "object" && window && window.Object === Object && window;
      var freeSelf = typeof self == "object" && self && self.Object === Object && self;
      var root = freeGlobal || freeSelf || Function("return this")();
      function getValue(object, key) {
        return object == null ? void 0 : object[key];
      }
      function isHostObject(value) {
        var result = false;
        if (value != null && typeof value.toString != "function") {
          try {
            result = !!(value + "");
          } catch (e) {
          }
        }
        return result;
      }
      var arrayProto = Array.prototype, funcProto = Function.prototype, objectProto = Object.prototype;
      var coreJsData = root["__core-js_shared__"];
      var maskSrcKey = function() {
        var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || "");
        return uid ? "Symbol(src)_1." + uid : "";
      }();
      var funcToString = funcProto.toString;
      var hasOwnProperty = objectProto.hasOwnProperty;
      var objectToString = objectProto.toString;
      var reIsNative = RegExp("^" + funcToString.call(hasOwnProperty).replace(reRegExpChar, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
      var Symbol = root.Symbol, splice = arrayProto.splice;
      var Map = getNative(root, "Map"), nativeCreate = getNative(Object, "create");
      var symbolProto = Symbol ? Symbol.prototype : void 0, symbolToString = symbolProto ? symbolProto.toString : void 0;
      function Hash(entries) {
        var index = -1, length = entries ? entries.length : 0;
        this.clear();
        while (++index < length) {
          var entry = entries[index];
          this.set(entry[0], entry[1]);
        }
      }
      function hashClear() {
        this.__data__ = nativeCreate ? nativeCreate(null) : {};
      }
      function hashDelete(key) {
        return this.has(key) && delete this.__data__[key];
      }
      function hashGet(key) {
        var data = this.__data__;
        if (nativeCreate) {
          var result = data[key];
          return result === HASH_UNDEFINED ? void 0 : result;
        }
        return hasOwnProperty.call(data, key) ? data[key] : void 0;
      }
      function hashHas(key) {
        var data = this.__data__;
        return nativeCreate ? data[key] !== void 0 : hasOwnProperty.call(data, key);
      }
      function hashSet(key, value) {
        var data = this.__data__;
        data[key] = nativeCreate && value === void 0 ? HASH_UNDEFINED : value;
        return this;
      }
      Hash.prototype.clear = hashClear;
      Hash.prototype["delete"] = hashDelete;
      Hash.prototype.get = hashGet;
      Hash.prototype.has = hashHas;
      Hash.prototype.set = hashSet;
      function ListCache(entries) {
        var index = -1, length = entries ? entries.length : 0;
        this.clear();
        while (++index < length) {
          var entry = entries[index];
          this.set(entry[0], entry[1]);
        }
      }
      function listCacheClear() {
        this.__data__ = [];
      }
      function listCacheDelete(key) {
        var data = this.__data__, index = assocIndexOf(data, key);
        if (index < 0) {
          return false;
        }
        var lastIndex = data.length - 1;
        if (index == lastIndex) {
          data.pop();
        } else {
          splice.call(data, index, 1);
        }
        return true;
      }
      function listCacheGet(key) {
        var data = this.__data__, index = assocIndexOf(data, key);
        return index < 0 ? void 0 : data[index][1];
      }
      function listCacheHas(key) {
        return assocIndexOf(this.__data__, key) > -1;
      }
      function listCacheSet(key, value) {
        var data = this.__data__, index = assocIndexOf(data, key);
        if (index < 0) {
          data.push([key, value]);
        } else {
          data[index][1] = value;
        }
        return this;
      }
      ListCache.prototype.clear = listCacheClear;
      ListCache.prototype["delete"] = listCacheDelete;
      ListCache.prototype.get = listCacheGet;
      ListCache.prototype.has = listCacheHas;
      ListCache.prototype.set = listCacheSet;
      function MapCache(entries) {
        var index = -1, length = entries ? entries.length : 0;
        this.clear();
        while (++index < length) {
          var entry = entries[index];
          this.set(entry[0], entry[1]);
        }
      }
      function mapCacheClear() {
        this.__data__ = {
          hash: new Hash(),
          map: new (Map || ListCache)(),
          string: new Hash()
        };
      }
      function mapCacheDelete(key) {
        return getMapData(this, key)["delete"](key);
      }
      function mapCacheGet(key) {
        return getMapData(this, key).get(key);
      }
      function mapCacheHas(key) {
        return getMapData(this, key).has(key);
      }
      function mapCacheSet(key, value) {
        getMapData(this, key).set(key, value);
        return this;
      }
      MapCache.prototype.clear = mapCacheClear;
      MapCache.prototype["delete"] = mapCacheDelete;
      MapCache.prototype.get = mapCacheGet;
      MapCache.prototype.has = mapCacheHas;
      MapCache.prototype.set = mapCacheSet;
      function assignValue(object, key, value) {
        var objValue = object[key];
        if (!(hasOwnProperty.call(object, key) && eq(objValue, value)) || value === void 0 && !(key in object)) {
          object[key] = value;
        }
      }
      function assocIndexOf(array, key) {
        var length = array.length;
        while (length--) {
          if (eq(array[length][0], key)) {
            return length;
          }
        }
        return -1;
      }
      function baseGet(object, path) {
        path = isKey(path, object) ? [path] : castPath(path);
        var index = 0, length = path.length;
        while (object != null && index < length) {
          object = object[toKey(path[index++])];
        }
        return index && index == length ? object : void 0;
      }
      function baseIsNative(value) {
        if (!isObject(value) || isMasked(value)) {
          return false;
        }
        var pattern = isFunction(value) || isHostObject(value) ? reIsNative : reIsHostCtor;
        return pattern.test(toSource(value));
      }
      function baseSet(object, path, value, customizer) {
        if (!isObject(object)) {
          return object;
        }
        path = isKey(path, object) ? [path] : castPath(path);
        var index = -1, length = path.length, lastIndex = length - 1, nested = object;
        while (nested != null && ++index < length) {
          var key = toKey(path[index]), newValue = value;
          if (index != lastIndex) {
            var objValue = nested[key];
            newValue = customizer ? customizer(objValue, key, nested) : void 0;
            if (newValue === void 0) {
              newValue = isObject(objValue) ? objValue : isIndex(path[index + 1]) ? [] : {};
            }
          }
          assignValue(nested, key, newValue);
          nested = nested[key];
        }
        return object;
      }
      function baseToString(value) {
        if (typeof value == "string") {
          return value;
        }
        if (isSymbol(value)) {
          return symbolToString ? symbolToString.call(value) : "";
        }
        var result = value + "";
        return result == "0" && 1 / value == -INFINITY ? "-0" : result;
      }
      function baseUpdate(object, path, updater, customizer) {
        return baseSet(object, path, updater(baseGet(object, path)), customizer);
      }
      function castFunction(value) {
        return typeof value == "function" ? value : identity;
      }
      function castPath(value) {
        return isArray(value) ? value : stringToPath(value);
      }
      function getMapData(map, key) {
        var data = map.__data__;
        return isKeyable(key) ? data[typeof key == "string" ? "string" : "hash"] : data.map;
      }
      function getNative(object, key) {
        var value = getValue(object, key);
        return baseIsNative(value) ? value : void 0;
      }
      function isIndex(value, length) {
        length = length == null ? MAX_SAFE_INTEGER : length;
        return !!length && (typeof value == "number" || reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
      }
      function isKey(value, object) {
        if (isArray(value)) {
          return false;
        }
        var type = typeof value;
        if (type == "number" || type == "symbol" || type == "boolean" || value == null || isSymbol(value)) {
          return true;
        }
        return reIsPlainProp.test(value) || !reIsDeepProp.test(value) || object != null && value in Object(object);
      }
      function isKeyable(value) {
        var type = typeof value;
        return type == "string" || type == "number" || type == "symbol" || type == "boolean" ? value !== "__proto__" : value === null;
      }
      function isMasked(func) {
        return !!maskSrcKey && maskSrcKey in func;
      }
      var stringToPath = memoize(function(string) {
        string = toString(string);
        var result = [];
        if (reLeadingDot.test(string)) {
          result.push("");
        }
        string.replace(rePropName, function(match, number, quote, string2) {
          result.push(quote ? string2.replace(reEscapeChar, "$1") : number || match);
        });
        return result;
      });
      function toKey(value) {
        if (typeof value == "string" || isSymbol(value)) {
          return value;
        }
        var result = value + "";
        return result == "0" && 1 / value == -INFINITY ? "-0" : result;
      }
      function toSource(func) {
        if (func != null) {
          try {
            return funcToString.call(func);
          } catch (e) {
          }
          try {
            return func + "";
          } catch (e) {
          }
        }
        return "";
      }
      function memoize(func, resolver) {
        if (typeof func != "function" || resolver && typeof resolver != "function") {
          throw new TypeError(FUNC_ERROR_TEXT);
        }
        var memoized = function() {
          var args = arguments, key = resolver ? resolver.apply(this, args) : args[0], cache = memoized.cache;
          if (cache.has(key)) {
            return cache.get(key);
          }
          var result = func.apply(this, args);
          memoized.cache = cache.set(key, result);
          return result;
        };
        memoized.cache = new (memoize.Cache || MapCache)();
        return memoized;
      }
      memoize.Cache = MapCache;
      function eq(value, other) {
        return value === other || value !== value && other !== other;
      }
      var isArray = Array.isArray;
      function isFunction(value) {
        var tag = isObject(value) ? objectToString.call(value) : "";
        return tag == funcTag || tag == genTag;
      }
      function isObject(value) {
        var type = typeof value;
        return !!value && (type == "object" || type == "function");
      }
      function isObjectLike(value) {
        return !!value && typeof value == "object";
      }
      function isSymbol(value) {
        return typeof value == "symbol" || isObjectLike(value) && objectToString.call(value) == symbolTag;
      }
      function toString(value) {
        return value == null ? "" : baseToString(value);
      }
      function update(object, path, updater) {
        return object == null ? object : baseUpdate(object, path, castFunction(updater));
      }
      function identity(value) {
        return value;
      }
      module.exports = update;
    }
  };
  return __require(8);
})();
