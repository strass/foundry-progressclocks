import { MODULE_NAME } from "./settings.js";
import { generateClockTemplatePayload } from "./util/clocks.js";
const _ = require("lodash");
const popper = require("@popperjs/core");
const clockTemplate = `modules/${MODULE_NAME}/templates/clock.html`;
export default class Clock extends Application {
    constructor(options) {
        super(Object.assign(Object.assign({}, options), { template: clockTemplate }));
        this.getTicks = () => this.options.ticks;
        this.getId = () => this._id;
        this._setClock = (options) => {
            this.options = Object.assign(Object.assign({}, this.options), options);
            if (this.options.segments < 2)
                this.options.segments = 2;
            if (this.options.segments < this.options.ticks)
                this.options.ticks = this.options.segments;
            Clock.setClock(this._id, this.options);
            this.render(true, this.options);
        };
        this._handleClickSegment = (idx) => {
            if (idx === 0 && this.options.ticks === 1) {
                this.options.ticks = 0;
            }
            else {
                this.options.ticks = idx + 1;
            }
            this._setClock({ ticks: this.options.ticks });
        };
        options.template = clockTemplate;
        if (options.segments <= 1) {
            throw new Error("Clocks need at least 2 segments");
        }
        this.options.segments = options.segments;
        this.options.ticks = options.ticks;
        this._id = options._id || new Date().valueOf();
        if (Clock.userHasEditPermissions) {
            // sync globally
            this._setClock(this.options);
        }
    }
    static get defaultOptions() {
        const obj = mergeObject(super.defaultOptions, {
            segments: 4,
            ticks: 0,
            popOut: false,
            resizable: false,
            width: 64,
            template: clockTemplate,
            classes: ["progress-clocks", "clock"],
        });
        return obj;
    }
    static get userHasEditPermissions() {
        var _a, _b, _c;
        return game.user.hasRole((_c = (_b = (_a = game) === null || _a === void 0 ? void 0 : _a.permissions) === null || _b === void 0 ? void 0 : _b.SETTINGS_MODIFY[0]) !== null && _c !== void 0 ? _c : CONST.USER_ROLES.ASSISTANT);
    }
    /** @override */
    getData() {
        const data = super.getData();
        return Object.assign(Object.assign({}, data), generateClockTemplatePayload({
            segments: this.options.segments,
            ticks: this.options.ticks,
            size: this.position.width,
            title: this.options.title,
            id: this._id,
            edit: false,
        }));
    }
    /** @override */
    activateListeners(html) {
        const nav = html[2];
        this._contextMenu(html);
        const hasPermissions = Clock.userHasEditPermissions;
        if (!hasPermissions) {
            console.warn("User lacks edit permissions for WorldSettings");
            return;
        }
        // HANDLERS
        // plus/minus
        $(nav)
            .find(".plus")
            .click(() => {
            this._setClock({ segments: ++this.options.segments });
        });
        $(nav)
            .find(".minus")
            .click(() => {
            this._setClock({ segments: --this.options.segments });
        });
        // clock segments
        Array(this.options.segments)
            .fill(undefined)
            .forEach((_, idx) => {
            html
                .find(`.seg-${idx}`)
                .click(() => this._handleClickSegment(idx));
        });
    }
    /**
     * Create a Context Menu attached to each Macro button
     * @param html
     * @private
     */
    _contextMenu(html) {
        const svg = html[0];
        const nav = html[2];
        // $(nav).css({ visibility: "hidden" });
        const navBB = nav.getBoundingClientRect();
        const virtualElement = {
            getBoundingClientRect: () => {
                const bb = svg.getBoundingClientRect();
                const newObj = {
                    height: 0,
                    width: 0,
                    right: bb.right + (1 / 2) * navBB.width,
                    left: bb.right + (1 / 2) * navBB.width,
                    top: bb.top + (1 / 2) * bb.height - (1 / 2) * navBB.height,
                    bottom: bb.top + (1 / 2) * bb.height - (1 / 2) * navBB.height,
                };
                return newObj;
            },
        };
        popper.createPopper(virtualElement, nav, {});
    }
    /** @override */
    _updateObject(event, formData) {
        console.debug("_updateObject in", formData);
        // return this.object.update(formData);
    }
}
Clock.resetClocks = () => {
    return game.settings.set(MODULE_NAME, "clocks_v1" /* clocks */, []);
};
Clock.getClocks = () => {
    return game.settings.get(MODULE_NAME, "clocks_v1" /* clocks */);
};
Clock.createClock = (newClock = {
    ticks: 1,
    segments: 4,
    _id: new Date().valueOf(),
    title: "New Clock",
}) => {
    const clocks = Clock.getClocks();
    game.settings.set(MODULE_NAME, "clocks_v1" /* clocks */, [
        ...clocks,
        newClock,
    ]);
};
Clock.setClock = (id, options) => {
    if (!Clock.userHasEditPermissions) {
        console.warn("User lacks edit permissions");
        return;
    }
    const clocks = Clock.getClocks();
    const idx = clocks.findIndex(({ _id }) => id === _id);
    if (idx < 0) {
        console.error(`No clock found with id ${id}`);
        return;
    }
    const newClocks = _.update(clocks, `[${idx}]`, (clock) => (Object.assign(Object.assign(Object.assign({}, clock), options), { segments: Math.max(2, options.segments || clock.segments) })));
    game.settings.set(MODULE_NAME, "clocks_v1" /* clocks */, newClocks);
};
